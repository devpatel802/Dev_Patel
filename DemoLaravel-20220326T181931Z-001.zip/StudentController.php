<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class StudentController extends Controller
{
    function insertStudent(){
        return view('insertStudent');
    }

    function insertStudentData(Request $request){

        $rules = [
            'sroll'=>'required|integer|min:1|max:99999999999999999999',
            'senrol'=>'required|integer|min:1|max:99999999999999999999',
            'sname'=>'required|min:3|max:255',
            'semail'=>'required|min:5|max:255',
            'sphone'=>'required|integer|min:1|max:99999999999999999999',
            'ssem'=>'required|min:1|max:255',
            'scourse'=>'required|min:3|max:255',
        ];

        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return redirect('insertStudent')
            ->withInput()
            ->withErrors($validator);
        }
        else
        {
            $stu = new Student();
            $stu->student_roll = $request->input('sroll');
            $stu->student_enroll = $request->input('senrol');
            $stu->student_name = $request->input('sname');
            $stu->student_email = $request->input('semail');
            $stu->student_phone = $request->input('sphone');
            $stu->student_semester = $request->input('ssem');
            $stu->student_course = $request->input('scourse');
            $stu -> save();

            echo "<script>alert('Student Added Successfully')</script>";
            return view('insertStudent');
        }
    }

    function viewStudent(){
        $tabledata = Student::all();
        return view('viewStudent',['tabledata'=>$tabledata]);
    }

    function editStudentForm($id){
        $tabledata = DB::select('select * from student where id=?',[$id]);
        return view('editStudentData',['tabledata'=>$tabledata]);
    }

    function editStudentData(Request $request,$id){
        $rules = [
            'sroll'=>'required|integer|min:1|max:99999999999999999999',
            'senrol'=>'required|integer|min:1|max:99999999999999999999',
            'sname'=>'required|min:3|max:255',
            'semail'=>'required|min:5|max:255',
            'sphone'=>'required|integer|min:1|max:99999999999999999999',
            'ssem'=>'required|min:1|max:255',
            'scourse'=>'required|min:3|max:255',
        ];

        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return redirect('insertStudent')
            ->withInput()
            ->withErrors($validator);
        }
        else
        {
            $row = Student::where('id',$id)->update([
                'student_roll'=>$request->input('sroll'),'student_enroll'=>$request->input('senrol'),
                'student_name'=>$request->input('sname'),'student_email'=>$request->input('semail'),
                'student_phone'=>$request->input('sphone'),'student_semester'=>$request->input('ssem'),
                'student_course'=>$request->input('scourse')
        ]);

            echo $row." Records updated Successfully :) <br>";
            echo "<a href='/viewStudent'><b>Click here to display students</b></a> <br>";
        }
    }

    function deleteStudentData($id){
        $row = Student::where('id',$id)->delete();

        echo $row." Records deleted Successfully :) <br>";
        echo "<a href='/viewStudent'><b>Click here to display students</b></a> <br>";
    }
}
