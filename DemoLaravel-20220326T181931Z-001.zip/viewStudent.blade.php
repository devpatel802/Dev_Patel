<html>
	<head><title>
		View Student
	</title></head>
	<body>
		<table border="2" align="center" bgcolor="peela">
			<tr>
				<td><b>Student Id</b></td>
				<td><b>Student Roll</b></td>
				<td><b>Student Enroll</b></td>
				<td><b>Student Name</b></td>
				<td><b>Student Email</b></td>
				<td><b>Student Phone</b></td>
				<td><b>Student Semester</b></td>
				<td><b>Student Course</b></td>
				<td colspan="2" align="center"><b><font color="purple">Operations</font></b></td>
			</tr>
			@foreach($tabledata as $data)
			<tr>
				<td>{{ $data->id }}</td>
				<td>{{ $data->student_roll }}</td>
				<td>{{ $data->student_enroll }}</td>
				<td>{{ $data->student_name }}</td>
				<td>{{ $data->student_email }}</td>
				<td>{{ $data->student_phone }}</td>
				<td>{{ $data->student_semester }}</td>
				<td>{{ $data->student_course }}</td>
				<td><a href="/editStudentForm/{{ $data->id }}"><b>Update</b></a></td>
				<td><a href="/deleteStudentData/{{ $data->id }}"><b>Delete</b></a></td>
			</tr>
			@endforeach
			<tr>
				<td colspan="10" align="center"><b><a href="/insertStudent">Click here to add more Student</a></b></td>
			</tr>
		</table>
	</body>
</html>