<html>
	<head>
		<title>
			Insert Student
		</title>
	</head>
	<body>
		<form action="/insertStudentData">
			<table border="2" align="center">
				<tr>
					<td>Student Roll</td>
					<td><input type="number" name="sroll" value="{{ old('sroll') }}">
						@if($errors -> has('sroll'))
						<div class="error">{{ $errors->first('sroll') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td>Student Enroll</td>
					<td><input type="number" name="senrol" value="{{ old('senrol') }}">
					@if($errors -> has('senrol'))
						<div class="error">{{ $errors->first('senrol') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td>Student Name</td>
					<td><input type="text" name="sname" value="{{ old('sname') }}">
					@if($errors -> has('sname'))
						<div class="error">{{ $errors->first('sname') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td>Student Email</td>
					<td><input type="text" name="semail" value="{{ old('semail') }}">
					@if($errors -> has('semail'))
						<div class="error">{{ $errors->first('semail') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td>Student Phone</td>
					<td><input type="text" name="sphone" value="{{ old('sphone') }}">
					@if($errors -> has('sphone'))
						<div class="error">{{ $errors->first('sphone') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td>Student Semester</td>
					<td><input type="text" name="ssem" value="{{ old('ssem') }}">
					@if($errors -> has('ssem'))
						<div class="error">{{ $errors->first('ssem') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td>Student Course</td>
					<td><input type="text" name="scourse" value="{{ old('scourse') }}">
					@if($errors -> has('scourse'))
						<div class="error">{{ $errors->first('scourse') }}</div>
						@endif
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<input type="submit" name="submit" value="Add Submit">
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center">
						<a href="/viewStudent">View Student</a>
					</td>
				</tr>
			</table>
		</form>
	</body>
</html>