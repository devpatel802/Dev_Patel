<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('loginCheck','LoginController@checkData');
Route::get('/login1','LoginController@loginForm');
Route::get('logout','LoginController@logout');
Route::get('addToCart/{id}','productController@addToCart');
Route::get('viewCart','productController@viewCart');

Route::get('eventInsert','eventController@insertForm');
Route::get('insertEvent','eventController@insertEvent');


Route::get('edit1/{id}','productController@show');
Route::get('edit/{id}','productController@editData');
Route::get('deleteData/{id}','productController@deleteData');
Route::get('Display','productController@selectData');
Route::get('prodInsert','productController@insertForm');
Route::get('insertProd','productController@insertProd');
Route::get('/', function () {
    return view('welcome');
});

Route::get('/test', 'TestController@viewTest');

Route::get('/home', function () {
    return view('Home');
});

Route::get('/demo', 'UserController@dispDemo');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
