<html>
    <head>
    <title>Edit Form</title>
    </head>
    <body>
        <form action="/editStudentData/<?php echo $tabledata[0] ->id; ?>">
            <center>
                <table border="2">
                    <tr>
                    <td>Student Rollno:</td>
                    <td><input type="text" name="sroll" value="<?php echo $tabledata[0]->student_roll;?>">
                    </td>
                    </tr>

                    <tr>
                    <td>Student Enroll:</td>
                    <td><input type="text" name="senrol" value="<?php echo $tabledata[0]->student_enroll;?>">
                    </td>
                    </tr>

                    <tr>
                    <td>Student Name:</td>
                    <td><input type="text" name="sname" value="<?php echo $tabledata[0]->student_name;?>">
                    </td>
                    </tr>

                    <tr>
                    <td>Student Email:</td>
                    <td><input type="text" name="semail" value="<?php echo $tabledata[0]->student_email;?>">
                    </td>
                    </tr>

                    <tr>
                    <td>Student Phone:</td>
                    <td><input type="text" name="sphone" value="<?php echo $tabledata[0]->student_phone;?>">
                    </td>
                    </tr>

                    <tr>
                    <td>Student Semester:</td>
                    <td><input type="text" name="ssem" value="<?php echo $tabledata[0]->student_semester;?>">
                    </td>
                    </tr>

                    <tr>
                    <td>Student Course:</td>
                    <td><input type="text" name="scourse" value="<?php echo $tabledata[0]->student_course;?>">
                    </td>
                    </tr>


                    <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="submit" value="update">
                    </td>
                    </tr>

                </table>
            </center>
        </form>
    </body>
</html>