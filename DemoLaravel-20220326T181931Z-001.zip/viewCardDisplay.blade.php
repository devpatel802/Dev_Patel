<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Display Product</title>
</head>
<body>
	<?php 
		$user=Session::get('UserName');
		if($user != "")
		{
			echo "Welcome ".$user; 
		
	?>
	<a href="logout">Logout</a>

<table align= 'center' border='1'>
	@foreach($cart as $data)
	<tr>
		<td>{{$data}}</td>
	</tr>
	@endforeach
</table>
<?php
}?>