

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Display Product</title>
</head>
<body>
	<?php 
		$user=Session::get('UserName');
		if($user != "")
		{
			echo "Welcome ".$user; 
		
	?>
	<a href="logout">Logout</a>

<table align= 'center' border='1'>
				<tr>
					<td>Id</td>
					<td>ProductName</td>
					<td>ProductPrice</td>
					<td>ProductDescription</td>
					<td>ProductQuantity</td>
					<td><a href="viewCart">ViewCart</a></td>
				</tr>
				@foreach($tableData as $data)
				<tr>
					<td>{{ $data->id}}</td>
					<td>{{ $data->prodName}}</td>
					<td>{{ $data->prodPrice}}</td>
					<td>{{ $data->prodDescription}}</td>
					<td>{{ $data->quantity}}</td>
					<td><a href='edit1/{{ $data->id}}'>Update</a></td>
					<td><a href='deleteData/{{ $data->id}}'>Delete</a></td>	
					<td><a href='addToCart/{{ $data->id}}'>AddToCart</a></td>	
				</tr>
				@endforeach

			</table>
			Click Here to <a href='/prodInsert'>insert</a> new record..
		</center>
	<?php }
	else {
		echo "You are not Logged in";
		// code...
	}?>
</body>
</html>
