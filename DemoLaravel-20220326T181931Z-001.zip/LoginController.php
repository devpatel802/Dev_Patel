<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Product;
use Session;


class LoginController extends Controller
{
    //
    function loginForm()
    {
        return view('login');
    }
    function checkData(Request $request)
    {
        $unm=$request->input('uname');
        $pass=$request->input('password');
        $tableData1=DB::select('select * from users where name=? and password=?',[$unm,$pass]);
        if($tableData1)
        {
            $request->session()->put('UserName',$unm);
            return redirect('Display');
        }
        else
        {
            return view('login');
        }
    }
    function logout()
    {
        Session::forget('UserName');
        Session::flush();
        return view('login');
    }
}
