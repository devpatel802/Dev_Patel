@extends('layouts.app')
@section('content')

<<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Page</title>
</head>
<body>
	<form action="loginCheck" >
		<table border="1" align="center">
			<tr>
				<td>UserName:</td>
				<td><input type="text" name="uname"></td>

			</tr>
			<tr>
				<td>Password:</td>
				<td><input type="password" name="password"></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit"></td>
			</tr>
		</table>

	</form>

</body>
</html>

@endsection