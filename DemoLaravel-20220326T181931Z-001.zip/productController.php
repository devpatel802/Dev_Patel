<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Product;
use Session;

class productController extends Controller
{
    function insertForm()
    {
        return view('prodInsert');
    }
    function insertProd(Request $request)
    {
       $rules = [
            'pname' => 'required|min:5|max:255',
            'pprice'=>'required|integer|min:1',
            'pdesc'=>'required|min:3|max:255',
            'pquantity'=>'required|integer|min:1'
        ];
        $validator = Validator::make($request->all(),$rules);
        if ($validator->fails()) {
            return redirect('prodInsert')
            ->withInput()
            ->withErrors($validator);
        }



      //  $validator=Validator::make(['pname'=>$request->input('pname')],
       //     ['pname'=>'required|min:5']);

       // if($validator->fails())
       // {
       //     $msg=$validator->messages();
      //      return redirect()->back()->with('msg',$msg);
            //return $validator->errors()->all();
            //return redirect()->back()->withErrors($validator->errors()->all())->withInput($request->input());
                //return redirect('prodInsert')->withErrors($validator->errors());
     //   }
        else
        {
        $prod=new Product();
        $prod->prodName=$request->input('pname');
        $prod->prodPrice=$request->input('pprice');
        $prod->prodDescription=$request->input('pdesc');
        $prod->quantity=$request->input('pquantity');
        $prod->save();
    
        /*$pName=$request->input('pname');
        $price=$request->input('pprice');
        $pDesc=$request->input('pdesc');
        $pQuantity=$request->input('pquantity');
        $data=array('prodName'=>$pName,'prodPrice'=>$price,'prodDescription'=>$pDesc,'quantity'=>$pQuantity);
        DB::table('Product')->insert($data);*/
        echo "Record inserted successfully.<br/>";
      echo '<a href = "/prodInsert">Click Here</a> to go back.';
      echo 'Click <a href="/Display">Here</a> to display records.';
      }
    }
    public function selectData()
   {
        //$tableData = DB::select('select * from Product');
        $tableData=Product::all();
        return view('Display',['tableData'=>$tableData]);
   }
   public function show($id) 
   {
        $tableData = DB::select('select * from Product where id = ?',[$id]);
        //$tableData=Product::where('id',$id);
        return view('editForm',['tableData'=>$tableData]);
    }
    public function editData(Request $request,$id) 
    {/*
        $prod=Product::find($id);
        $prod->prodName=$request->input('name');
        $prod->prodPrice=$request->input('price');
        $prod->prodDescription=$request->input('desc');
        $prod->quantity=$request->input('quant');
        $prod->save();*/
        $noOfRow=Product::where('id',$id)->update(['prodName'=>$request->input('name'),'prodPrice'=>$request->input('price'),'prodDescription'=>$request->input('desc'),'quantity'=>$request->input('quant')]);

        /*$name = $request->input('name');
        $price = $request->input('price');
        $desc=$request->input('desc');
        $quant=$request->input('quant');
        DB::update('update Product set  prodName= ?,prodPrice=?,prodDescription=?, quantity=? where id = ?',[$name,$price,$desc,$quant,$id]);*/
        echo $noOfRow." Record updated successfully.";
        echo 'Click <a href="/Display">Here</a> to go back.';
    }
    public function deleteData($id)
    {
        //DB::table('Product')->delete($id);
        $noOfRow=Product::where('id',$id)->delete();

        echo $noOfRow.' Record deleted successfully..';
        echo 'Click <a href="/Display">Here</a> to go back.';
    }
    public function addToCart($id)
    {
        $unm=Session::get('UserName');
        if($unm != "")
        {
            $cart=Session::get('cart');
            if($cart != "")
            {
                array_push($cart,$id);
                Session::put('cart',$cart);
            }
            else
            {
                $cart=array($id);
                Session::put('cart',$cart);
            }
            //echo "added";
            return redirect('Display');
        }

    }
    public function viewCart()
    {
        $unm=Session::get('UserName');
        if($unm != "")
        {
            $cart=Session::get('cart');
            return view('viewCardDisplay',['cart'=>$cart]);
        }

    }
}
